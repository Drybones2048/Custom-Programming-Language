package plc.exercises.regextesting;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class RegexTests {

    @ParameterizedTest
    @MethodSource
    public void testEmailRegex(String test, String input, boolean matches) {
        test(input, Regex.EMAIL, matches);
    }

    public static Stream<Arguments> testEmailRegex() {
        return Stream.of(
            Arguments.of("Alphanumeric", "thelegend27@gmail.com", true),
            Arguments.of("UF Domain", "otherdomain@ufl.edu", true),
            Arguments.of("Missing Domain Dot", "missingdot@gmailcom", false),
            Arguments.of("Symbols", "symbols#$%@gmail.com", false)
            //TODO: Test coverage (*minimum* 5 matching, 5 non-matching)
        );
    }

    @ParameterizedTest
    @MethodSource
    public void testDiscountCsvRegex(String test, String input, boolean matches) {
        test(input, Regex.DISCOUNT_CSV, matches);
    }

    public static Stream<Arguments> testDiscountCsvRegex() {
        return Stream.of(
            Arguments.of("Single", "single", true),
            Arguments.of("Multiple", "one,two,three", true),
            Arguments.of("Spaces", "first , second", true),
            Arguments.of("Missing Value", "first,,second", false)
            //TODO: Test coverage (*minimum* 5 matching, 5 non-matching)
        );
    }

    @ParameterizedTest
    @MethodSource
    public void testDiceNotationRegex(String test, String input, boolean matches, Map<String, String> groups) {
        var matcher = Regex.DICE_NOTATION.matcher(input);
        Assertions.assertEquals(matches, matcher.matches());
        if (matches) {
            Assertions.assertEquals(groups, Regex.getGroups(matcher));
        }
    }

    public static Stream<Arguments> testDiceNotationRegex() {
        return Stream.of(
            Arguments.of("Standard Dice", "1d6", true, Map.of(
                "count", "1", "faces", "6"
            )),
            Arguments.of("Positive Bonus", "1d6+4", true, Map.of(
                "count", "1", "faces", "6", "bonus", "+4"
            )),
            Arguments.of("Missing Faces", "1d", false, Map.of()),
            Arguments.of("Negative Count", "-1d6", false, Map.of())
            //TODO: Test coverage (*minimum* 5 matching, 5 non-matching)
        );
    }

    @ParameterizedTest
    @MethodSource
    public void testNumberRegex(String test, String input, boolean matches) {
        test(input, Regex.NUMBER, matches);
    }

    public static Stream<Arguments> testNumberRegex() {
        //TODO: Test coverage (*minimum* 5 matching, 5 non-matching)
        throw new UnsupportedOperationException("TODO");
    }

    @ParameterizedTest
    @MethodSource
    public void testStringRegex(String test, String input, boolean matches) {
        test(input, Regex.STRING, matches);
    }

    public static Stream<Arguments> testStringRegex() {
        //TODO: Test coverage (*minimum* 5 matching, 5 non-matching)
        throw new UnsupportedOperationException("TODO");
    }

    private static void test(String input, Pattern pattern, boolean matches) {
        Assertions.assertEquals(matches, pattern.matcher(input).matches());
    }

}
